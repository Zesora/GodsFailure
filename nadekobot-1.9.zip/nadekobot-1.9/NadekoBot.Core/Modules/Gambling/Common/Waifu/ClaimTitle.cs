﻿namespace NadekoBot.Core.Modules.Gambling.Common.Waifu
{
    public enum ClaimTitle
    {
        Lonely,
        Devoted,
        Rookie,
        Schemer,
        Dilettante,
        Intermediate,
        Seducer,
        Expert,
        Veteran,
        Incubis,
        Harem_King,
        Harem_God,
    }
}
