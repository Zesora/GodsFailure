﻿namespace NadekoBot.Core.Modules.Gambling.Common.Waifu
{
    public enum DivorceResult
    {
        Success,
        SucessWithPenalty,
        NotYourWife,
        Cooldown
    }
}
