﻿namespace NadekoBot.Core.Modules.Gambling.Common.Waifu
{
    public enum WaifuClaimResult
    {
        Success,
        NotEnoughFunds,
        InsufficientAmount
    }
}
